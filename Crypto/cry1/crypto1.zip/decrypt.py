def xor_decrypt(enc_file, key_file, offset):
    with open(enc_file, 'rb') as f1:
        ciphertext = f1.read()
    with open(key_file, 'rb') as f2:
        f2.seek(offset)
        key_stream = f2.read(len(ciphertext))
    plaintext = bytearray()
    for i in range(len(ciphertext)):
        plaintext.append(ciphertext[i] ^ key_stream[i])
    return plaintext

if __name__ == '__main__':
    OFFSET = 233812
    result = xor_decrypt('flag.enc', 'key.bin', OFFSET)
    with open('decrypt_file', 'wb') as f:
        f.write(result)
    print("ok.")
